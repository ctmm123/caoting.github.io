import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { RESUME_DATA } from '../constants';
import { Download, ChevronDown, Camera, Eye } from 'lucide-react';

export const Hero: React.FC = () => {
  const [avatar, setAvatar] = useState<string>(RESUME_DATA.avatar);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    // Check local storage for saved avatar on mount
    const savedAvatar = localStorage.getItem('nexus_resume_avatar');
    if (savedAvatar) {
      setAvatar(savedAvatar);
    }
  }, []);

  const handleAvatarClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Validate file type
      if (!file.type.startsWith('image/')) {
        alert('请上传图片文件');
        return;
      }
      
      // Validate file size (e.g., max 2MB to prevent localStorage quota issues)
      if (file.size > 2 * 1024 * 1024) {
        alert('图片大小请限制在 2MB 以内');
        return;
      }

      const reader = new FileReader();
      reader.onloadend = () => {
        const result = reader.result as string;
        setAvatar(result);
        try {
          localStorage.setItem('nexus_resume_avatar', result);
        } catch (e) {
          console.warn('Unable to save image to localStorage (likely quota exceeded). Image will reset on refresh.');
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const getHTMLContent = () => {
    const { name, title, tagline, about, experience, education, skills, projects, socials } = RESUME_DATA;
    
    return `
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${name} - 简历</title>
  <style>
    :root {
      --primary: #2c3e50;
      --accent: #0891b2;
      --text: #334155;
      --light-bg: #f8fafc;
    }
    body { 
      font-family: 'PingFang SC', 'Microsoft YaHei', 'Helvetica Neue', Helvetica, Arial, sans-serif; 
      line-height: 1.6; 
      color: var(--text); 
      background: #525659; 
      margin: 0; 
      padding: 20px;
      display: flex;
      justify-content: center;
    }
    .page {
      background: white;
      width: 100%;
      max-width: 210mm; /* A4 width */
      min-height: 297mm;
      padding: 40px 50px;
      box-shadow: 0 0 20px rgba(0,0,0,0.5);
      box-sizing: border-box;
      position: relative;
    }
    header { 
      display: flex; 
      align-items: center; 
      border-bottom: 2px solid #f1f5f9; 
      padding-bottom: 30px; 
      margin-bottom: 30px; 
      gap: 30px;
    }
    .header-info { flex: 1; }
    .avatar-container {
      width: 100px;
      height: 100px;
      border-radius: 50%;
      overflow: hidden;
      border: 3px solid #e2e8f0;
      flex-shrink: 0;
    }
    .avatar-container img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
    h1 { font-size: 32px; margin: 0 0 5px; color: var(--primary); letter-spacing: -0.5px; }
    .job-title { font-size: 18px; color: var(--accent); margin-bottom: 10px; font-weight: 500; }
    .tagline { font-size: 14px; color: #64748b; margin-bottom: 15px; }
    
    .contact-grid { 
      display: flex; 
      flex-wrap: wrap; 
      gap: 15px; 
      font-size: 13px; 
      color: #64748b; 
    }
    .contact-item { 
      display: flex; 
      align-items: center; 
      gap: 6px; 
      background: #f1f5f9;
      padding: 4px 10px;
      border-radius: 4px;
    }
    .contact-item a { color: inherit; text-decoration: none; }

    section { margin-bottom: 30px; }
    .section-title { 
      font-size: 16px; 
      font-weight: 700;
      color: var(--primary); 
      border-bottom: 2px solid #e2e8f0; 
      padding-bottom: 8px; 
      margin-bottom: 20px; 
      text-transform: uppercase; 
      letter-spacing: 1px; 
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .section-title::before {
      content: '';
      display: block;
      width: 6px;
      height: 6px;
      background: var(--accent);
      border-radius: 50%;
    }

    .experience-item, .project-item { margin-bottom: 25px; page-break-inside: avoid; }
    .item-header { display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 4px; }
    h3 { font-size: 16px; font-weight: 700; color: #1e293b; margin: 0; }
    .period { font-size: 13px; color: #64748b; font-family: Consolas, monospace; background: #f8fafc; padding: 2px 6px; border-radius: 4px; }
    .company { font-size: 14px; color: #0f172a; font-weight: 500; margin-bottom: 8px; }
    
    ul { margin: 8px 0; padding-left: 18px; }
    li { margin-bottom: 4px; font-size: 14px; color: #475569; text-align: justify; }
    
    .tags { display: flex; flex-wrap: wrap; gap: 6px; margin-top: 8px; }
    .tag { background: #eff6ff; color: #1e40af; padding: 2px 8px; border-radius: 3px; font-size: 12px; border: 1px solid #dbeafe; }

    .skills-grid { 
      display: grid; 
      grid-template-columns: repeat(2, 1fr); 
      column-gap: 40px; 
      row-gap: 12px; 
    }
    .skill-item { display: flex; align-items: center; justify-content: space-between; font-size: 14px; }
    .skill-name { color: #334155; font-weight: 500; }
    .progress-bg { width: 120px; height: 6px; background: #e2e8f0; border-radius: 3px; overflow: hidden; }
    .progress-bar { height: 100%; background: var(--accent); }

    .edu-item { margin-bottom: 15px; }
    
    .footer { 
      text-align: center; 
      margin-top: 40px; 
      padding-top: 20px; 
      border-top: 1px solid #f1f5f9; 
      font-size: 12px; 
      color: #94a3b8; 
    }

    @media print {
      body { background: white; padding: 0; display: block; }
      .page { width: 100%; max-width: none; box-shadow: none; padding: 0; margin: 0; min-height: auto; }
      a { text-decoration: none; color: #333; }
      @page { margin: 1.5cm; size: A4; }
    }
  </style>
</head>
<body>
  <div class="page">
    <header>
      <div class="avatar-container">
        <img src="${avatar}" alt="${name}">
      </div>
      <div class="header-info">
        <h1>${name}</h1>
        <div class="job-title">${title}</div>
        <div class="tagline">${tagline}</div>
        <div class="contact-grid">
          ${socials.map(s => `
            <div class="contact-item">
              <a href="${s.url}">${s.url.replace('tel:', '').replace('mailto:', '')}</a>
            </div>
          `).join('')}
        </div>
      </div>
    </header>

    <section>
      <div class="section-title">个人简介</div>
      <p style="font-size: 14px; color: #475569; line-height: 1.7;">${about}</p>
    </section>

    <section>
      <div class="section-title">工作经历</div>
      ${experience.map(job => `
        <div class="experience-item">
          <div class="item-header">
            <h3>${job.role}</h3>
            <span class="period">${job.period}</span>
          </div>
          <div class="company">${job.company}</div>
          <ul>
            ${job.description.map(desc => `<li>${desc}</li>`).join('')}
          </ul>
          <div class="tags">
            ${job.techStack.map(stack => `<span class="tag">${stack}</span>`).join('')}
          </div>
        </div>
      `).join('')}
    </section>

    <section>
      <div class="section-title">核心技能</div>
      <div class="skills-grid">
        ${skills.map(skill => `
          <div class="skill-item">
            <span class="skill-name">${skill.subject}</span>
            <div class="progress-bg">
              <div class="progress-bar" style="width: ${skill.A}%"></div>
            </div>
          </div>
        `).join('')}
      </div>
    </section>

    <section>
      <div class="section-title">重点项目</div>
      ${projects.map(project => `
        <div class="project-item">
          <div class="item-header">
            <h3>${project.title}</h3>
          </div>
          <p style="font-size: 14px; color: #475569; margin: 5px 0 8px;">${project.description}</p>
          <div class="tags">
            ${project.tags.map(tag => `<span class="tag">${tag}</span>`).join('')}
          </div>
        </div>
      `).join('')}
    </section>

    <section>
      <div class="section-title">教育背景</div>
      ${education.map(edu => `
        <div class="edu-item">
          <div class="item-header">
            <h3 style="font-weight: 600;">${edu.school}</h3>
            <span class="period">${edu.year}</span>
          </div>
          <div style="font-size: 14px; color: #64748b;">${edu.degree} · ${edu.details}</div>
        </div>
      `).join('')}
    </section>

    <div class="footer">
      Generated by Nexus Resume AI
    </div>
  </div>
</body>
</html>
    `;
  };

  const handleDownload = () => {
    const htmlContent = getHTMLContent();
    const blob = new Blob([htmlContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${RESUME_DATA.name}_简历.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handlePreview = () => {
    const htmlContent = getHTMLContent();
    const blob = new Blob([htmlContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    window.open(url, '_blank');
  };

  return (
    <section id="hero" className="min-h-screen flex flex-col justify-center items-center pt-20 relative">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="text-center z-10"
      >
        <div className="relative mb-8 inline-block group">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", stiffness: 260, damping: 20 }}
            className="w-32 h-32 md:w-40 md:h-40 rounded-full border-4 border-cyan-500/30 overflow-hidden relative z-10 bg-slate-800"
          >
            <img 
              src={avatar} 
              alt={RESUME_DATA.name} 
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
            />
            
            {/* Edit Overlay */}
            <div 
              onClick={handleAvatarClick}
              className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col items-center justify-center cursor-pointer backdrop-blur-sm"
            >
              <Camera className="text-white mb-1" size={24} />
              <span className="text-white/90 text-xs font-medium">更换头像</span>
            </div>
          </motion.div>

          {/* Hidden Input */}
          <input 
            type="file" 
            ref={fileInputRef}
            onChange={handleFileChange}
            accept="image/*"
            className="hidden"
          />

          {/* Animated decorative ring */}
          <div className="absolute top-[-10px] left-[-10px] right-[-10px] bottom-[-10px] rounded-full border border-dashed border-cyan-500/20 animate-spin-slow pointer-events-none" />
        </div>

        <motion.h2 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="text-cyan-400 font-medium tracking-widest text-sm md:text-base uppercase mb-4"
        >
          你好，我是 {RESUME_DATA.name}
        </motion.h2>

        <h1 className="text-5xl md:text-7xl font-bold mb-6 tracking-tight">
          <span className="block text-slate-100">欢迎来到</span>
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500">
             我的主页
          </span>
        </h1>

        <p className="max-w-xl mx-auto text-slate-400 text-lg md:text-xl leading-relaxed mb-10">
          {RESUME_DATA.tagline}
        </p>

        <div className="flex flex-col md:flex-row gap-4 justify-center items-center">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleDownload}
            className="px-8 py-3 bg-cyan-500 hover:bg-cyan-600 text-slate-950 font-bold rounded-full transition-all flex items-center gap-2"
          >
            <Download size={18} />
            下载简历
          </motion.button>
          
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handlePreview}
            className="px-8 py-3 glass-card text-white font-medium rounded-full hover:bg-white/10 transition-all border border-white/10 flex items-center gap-2"
          >
            <Eye size={18} />
            在线预览
          </motion.button>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1, y: [0, 10, 0] }}
        transition={{ delay: 1.5, duration: 2, repeat: Infinity }}
        className="absolute bottom-10 left-1/2 transform -translate-x-1/2 text-slate-500 cursor-pointer"
        onClick={() => document.getElementById('experience')?.scrollIntoView({ behavior: 'smooth' })}
      >
        <ChevronDown size={32} />
      </motion.div>
    </section>
  );
};
