import React from 'react';
import { motion } from 'framer-motion';
import { RESUME_DATA } from '../constants';
import { Mail } from 'lucide-react';

export const Contact: React.FC = () => {
  return (
    <section id="contact" className="py-20 text-center">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="max-w-2xl mx-auto glass-card p-10 rounded-3xl border border-slate-800"
      >
        <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">期待与您合作</h2>
        <p className="text-slate-400 mb-8 text-lg">
          我目前正在寻找新的职业机会。无论是关于HRBP职位的咨询，还是技术交流，欢迎随时联系我！
        </p>

        <div className="flex justify-center gap-6 mb-10">
          {RESUME_DATA.socials.map((social) => (
            <motion.a
              key={social.name}
              href={social.url}
              whileHover={{ scale: 1.2, rotate: 5 }}
              className="p-4 bg-slate-800/50 rounded-full text-cyan-400 hover:bg-cyan-500 hover:text-slate-900 transition-colors"
            >
              {social.icon}
            </motion.a>
          ))}
        </div>

        <motion.a
          href={`mailto:${RESUME_DATA.socials.find(s => s.name === 'Email')?.url.replace('mailto:', '')}`}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="inline-flex items-center gap-2 px-8 py-3 bg-gradient-to-r from-purple-600 to-cyan-600 text-white font-bold rounded-full shadow-lg shadow-purple-900/50"
        >
          <Mail size={18} />
          发送邮件
        </motion.a>
      </motion.div>
    </section>
  );
};