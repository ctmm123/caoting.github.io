import React from 'react';
import { motion } from 'framer-motion';
import { ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, Tooltip } from 'recharts';
import { RESUME_DATA } from '../constants';
import { Database } from 'lucide-react';

export const Skills: React.FC = () => {
  return (
    <section id="skills" className="py-20 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-cyan-900/5 to-transparent pointer-events-none" />
      
      <div className="flex items-center gap-4 mb-12 relative z-10">
        <div className="p-3 rounded-lg bg-cyan-500/10 text-cyan-400">
          <Database size={24} />
        </div>
        <h2 className="text-3xl md:text-4xl font-bold text-slate-100">核心技能</h2>
      </div>

      <div className="flex flex-col lg:flex-row gap-12 items-center">
        {/* Chart */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.8 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="w-full lg:w-1/2 h-[400px] glass-card rounded-2xl p-4 flex items-center justify-center"
        >
          <ResponsiveContainer width="100%" height="100%">
            <RadarChart cx="50%" cy="50%" outerRadius="70%" data={RESUME_DATA.skills}>
              <PolarGrid stroke="rgba(255,255,255,0.1)" />
              <PolarAngleAxis dataKey="subject" tick={{ fill: '#94a3b8', fontSize: 12 }} />
              <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
              <Radar
                name="熟练度"
                dataKey="A"
                stroke="#06b6d4"
                strokeWidth={3}
                fill="#06b6d4"
                fillOpacity={0.3}
              />
              <Tooltip 
                contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#f8fafc' }}
                itemStyle={{ color: '#22d3ee' }}
              />
            </RadarChart>
          </ResponsiveContainer>
        </motion.div>

        {/* List Details */}
        <div className="w-full lg:w-1/2 grid grid-cols-1 md:grid-cols-2 gap-6">
          {RESUME_DATA.skills.map((skill, index) => (
            <motion.div
              key={skill.subject}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-slate-900/50 p-4 rounded-xl border border-slate-800"
            >
              <div className="flex justify-between mb-2">
                <span className="font-semibold text-slate-200">{skill.subject}</span>
                <span className="text-cyan-400 font-mono">{skill.A}%</span>
              </div>
              <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  whileInView={{ width: `${skill.A}%` }}
                  transition={{ duration: 1, delay: 0.5 }}
                  className="h-full bg-gradient-to-r from-cyan-600 to-purple-500"
                />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};