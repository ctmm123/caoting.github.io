import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { RESUME_DATA } from '../constants';
import { Layout, ExternalLink, ArrowRight } from 'lucide-react';

export const Projects: React.FC = () => {
  const [hoveredId, setHoveredId] = useState<string | null>(null);

  return (
    <section id="projects" className="py-20">
      <div className="flex items-center gap-4 mb-12">
        <div className="p-3 rounded-lg bg-pink-500/10 text-pink-400">
          <Layout size={24} />
        </div>
        <h2 className="text-3xl md:text-4xl font-bold text-slate-100">重点项目</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {RESUME_DATA.projects.map((project) => (
          <motion.div
            key={project.id}
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="group relative h-[400px] rounded-2xl overflow-hidden cursor-pointer shadow-2xl shadow-black/40"
            onMouseEnter={() => setHoveredId(project.id)}
            onMouseLeave={() => setHoveredId(null)}
          >
            {/* Background Image */}
            <div className="absolute inset-0">
              <img 
                src={project.image} 
                alt={project.title} 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-slate-950/40 group-hover:bg-slate-950/70 transition-colors duration-300" />
            </div>

            {/* Content Content - Default State */}
            <div className="absolute bottom-0 left-0 w-full p-6 transition-transform duration-300 transform group-hover:-translate-y-4">
               <h3 className="text-2xl font-bold text-white mb-2">{project.title}</h3>
               <div className="flex flex-wrap gap-2">
                 {project.tags.slice(0, 3).map(tag => (
                   <span key={tag} className="text-xs text-slate-300 bg-white/10 px-2 py-1 rounded backdrop-blur-sm">
                     {tag}
                   </span>
                 ))}
               </div>
            </div>

            {/* Hover Overlay Details */}
            <AnimatePresence>
              {hoveredId === project.id && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="absolute inset-0 flex flex-col justify-center items-center p-8 bg-slate-950/80 backdrop-blur-sm text-center"
                >
                  <h3 className="text-2xl font-bold text-cyan-400 mb-4">{project.title}</h3>
                  <p className="text-slate-300 mb-6 leading-relaxed">
                    {project.description}
                  </p>
                  <a 
                    href={project.link}
                    className="flex items-center gap-2 text-white border border-white/30 px-6 py-2 rounded-full hover:bg-white hover:text-slate-900 transition-all"
                  >
                    查看详情 <ExternalLink size={16} />
                  </a>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        ))}
      </div>
    </section>
  );
};