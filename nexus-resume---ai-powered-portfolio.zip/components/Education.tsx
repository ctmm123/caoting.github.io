import React from 'react';
import { motion } from 'framer-motion';
import { RESUME_DATA } from '../constants';
import { GraduationCap } from 'lucide-react';

export const Education: React.FC = () => {
  return (
    <section id="education" className="py-20">
      <div className="flex items-center gap-4 mb-12">
        <div className="p-3 rounded-lg bg-orange-500/10 text-orange-400">
          <GraduationCap size={24} />
        </div>
        <h2 className="text-3xl md:text-4xl font-bold text-slate-100">教育背景</h2>
      </div>

      <div className="relative border-l-2 border-slate-800 ml-3 md:ml-6 space-y-12">
        {RESUME_DATA.education.map((edu, index) => (
          <motion.div 
            key={edu.id}
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="relative pl-8 md:pl-12"
          >
            {/* Timeline Dot */}
            <div className="absolute top-0 left-[-9px] w-4 h-4 rounded-full bg-slate-950 border-2 border-orange-500" />
            
            <div className="glass-card p-6 rounded-xl">
              <div className="flex flex-col md:flex-row md:items-center justify-between mb-2">
                <h3 className="text-xl font-bold text-white">{edu.school}</h3>
                <span className="text-orange-400 font-mono text-sm">{edu.year}</span>
              </div>
              <h4 className="text-lg text-slate-300 mb-2">{edu.degree}</h4>
              <p className="text-slate-500 text-sm">{edu.details}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
};