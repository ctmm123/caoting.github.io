import React from 'react';
import { motion } from 'framer-motion';
import { RESUME_DATA } from '../constants';
import { Briefcase } from 'lucide-react';

export const Experience: React.FC = () => {
  return (
    <section id="experience" className="py-20">
      <div className="flex items-center gap-4 mb-12">
        <div className="p-3 rounded-lg bg-purple-500/10 text-purple-400">
          <Briefcase size={24} />
        </div>
        <h2 className="text-3xl md:text-4xl font-bold text-slate-100">工作经历</h2>
      </div>

      <div className="grid grid-cols-1 gap-8">
        {RESUME_DATA.experience.map((job, index) => (
          <motion.div
            key={job.id}
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            className="glass-card p-6 md:p-8 rounded-2xl relative overflow-hidden group hover:border-purple-500/30 transition-colors"
          >
            {/* Hover Background Effect */}
            <div className="absolute inset-0 bg-gradient-to-r from-purple-900/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />

            <div className="relative z-10 flex flex-col md:flex-row md:items-start md:justify-between gap-4 mb-6">
              <div>
                <h3 className="text-2xl font-bold text-white mb-1 group-hover:text-purple-300 transition-colors">{job.role}</h3>
                <h4 className="text-lg text-slate-400">{job.company}</h4>
              </div>
              <div className="px-4 py-1 rounded-full bg-slate-800/50 border border-slate-700 text-sm text-slate-300 w-fit">
                {job.period}
              </div>
            </div>

            <ul className="space-y-3 mb-6 relative z-10">
              {job.description.map((desc, i) => (
                <li key={i} className="flex items-start gap-3 text-slate-400">
                  <span className="mt-2 w-1.5 h-1.5 rounded-full bg-cyan-500 flex-shrink-0" />
                  <span className="leading-relaxed">{desc}</span>
                </li>
              ))}
            </ul>

            <div className="flex flex-wrap gap-2 relative z-10">
              {job.techStack.map((tech) => (
                <span 
                  key={tech} 
                  className="px-3 py-1 text-xs font-mono rounded bg-white/5 border border-white/5 text-cyan-200"
                >
                  {tech}
                </span>
              ))}
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
};