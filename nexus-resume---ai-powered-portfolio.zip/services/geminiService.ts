import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { RESUME_DATA } from "../constants";

// Helper to get text from response safely
const getResponseText = (response: GenerateContentResponse): string => {
  if (response.text) {
    return response.text;
  }
  return "抱歉，我现在无法生成回复。";
};

export const generateAIResponse = async (userPrompt: string): Promise<string> => {
  try {
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
      console.warn("API_KEY is missing from environment variables.");
      return "由于未配置API Key，我目前处于演示模式。请配置API_KEY以与我交流！";
    }

    const ai = new GoogleGenAI({ apiKey });
    
    // Construct a system prompt that gives the model persona and context
    const systemPrompt = `
      你是一个AI助手，代表曹婷（Cao Ting），一位资深的HRBP和AI应用探索者。
      你的目标是根据以下JSON数据回答有关曹婷的职业背景、技能和项目的问题。
      
      简历数据:
      ${JSON.stringify(RESUME_DATA)}

      指导原则:
      1. 保持专业、友好且简洁的语气。
      2. 如果被问及数据中没有的信息，请礼貌地说明你没有相关信息。
      3. 尽可能强调具体的成就指标（例如“提高协同效率”、“量化管理”）。
      4. 除非对方要求详细说明，否则保持回答简短（100字以内）。
      5. 使用第三人称（助手）的口吻回答。
      6. 请始终使用中文回答。
    `;

    const modelId = 'gemini-2.5-flash';

    const response = await ai.models.generateContent({
      model: modelId,
      contents: [
        { role: 'user', parts: [{ text: systemPrompt }] },
        { role: 'user', parts: [{ text: userPrompt }] }
      ],
    });

    return getResponseText(response);
    
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "我现在连接大脑有点困难，请稍后再试。";
  }
};